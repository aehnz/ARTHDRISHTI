import puppeteer from 'puppeteer-core';
import { PDFDocument } from 'pdf-lib';

const ROOT = '/Users/aehnz/Desktop/Saarthi-AI';
const browser = await puppeteer.launch({
  executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  headless: 'new',
});
const page = await browser.newPage();
await page.goto(`file://${ROOT}/.report-build/arthdrishti.html`, { waitUntil: 'networkidle0' });
await page.evaluateHandle('document.fonts.ready');

const pdf = await page.pdf({
  path: `${ROOT}/ARTHDRISHTI_HackOut26_Report.pdf`,
  format: 'A4',
  printBackground: true,
  preferCSSPageSize: true,
  margin: { top: 0, bottom: 0, left: 0, right: 0 },
});
await browser.close();
const doc = await PDFDocument.load(pdf);
console.log('PDF pages:', doc.getPageCount());
