import puppeteer from 'puppeteer-core';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const ROOT = '/Users/aehnz/Desktop/Saarthi-AI';
mkdirSync(`${ROOT}/.report-build/pages`, { recursive: true });
const pdfPath = process.argv[2] || `${ROOT}/HackOut26_BharatBanking_Report.pdf`;
const pdfB64 = readFileSync(pdfPath).toString('base64');

const browser = await puppeteer.launch({
  executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  headless: 'new',
});
const page = await browser.newPage();
await page.setContent('<html><body></body></html>');
await page.addScriptTag({ url: 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js' });
const numPages = await page.evaluate(async (b64) => {
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js';
  const raw = atob(b64);
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  const pdf = await pdfjsLib.getDocument({ data: arr }).promise;
  window.__pdf = pdf;
  return pdf.numPages;
}, pdfB64);

for (let n = 1; n <= numPages; n++) {
  const dataUrl = await page.evaluate(async (n) => {
    const pg = await window.__pdf.getPage(n);
    const vp = pg.getViewport({ scale: 1.6 });
    const canvas = document.createElement('canvas');
    canvas.width = vp.width; canvas.height = vp.height;
    await pg.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
    return canvas.toDataURL('image/png');
  }, n);
  writeFileSync(`${ROOT}/.report-build/pages/page-${n}.png`, Buffer.from(dataUrl.split(',')[1], 'base64'));
}
await browser.close();
console.log('Rendered', numPages, 'pages');
