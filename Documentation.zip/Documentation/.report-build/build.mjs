import { readFileSync, writeFileSync } from 'node:fs';
import { marked } from 'marked';
import puppeteer from 'puppeteer-core';
import { PDFDocument } from 'pdf-lib';

const ROOT = '/Users/aehnz/Desktop/Saarthi-AI';
const md = readFileSync(`${ROOT}/HackOut26_BharatBanking_Report.md`, 'utf8');

// --- Markdown -> HTML, converting mermaid fences to divs with per-diagram index ---
let mermaidIdx = 0;
const renderer = new marked.Renderer();
const origCode = renderer.code.bind(renderer);
renderer.code = function (token) {
  if (token.lang === 'mermaid') {
    const i = mermaidIdx++;
    return `<div class="mermaid-wrap mw-${i}"><pre class="mermaid">${token.text
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre></div>`;
  }
  return origCode(token);
};
marked.setOptions({ renderer, gfm: true });
const body = marked.parse(md);

const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<style>
  :root {
    --navy: #16324f; --accent: #1f5c8b; --ink: #1c2733; --muted: #5a6b7d;
    --line: #cfd8e3; --panel: #f2f6fa;
  }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-size: 8.35pt; line-height: 1.26; color: var(--ink);
    -webkit-print-color-adjust: exact; print-color-adjust: exact;
  }
  h1 { font-size: 15pt; color: var(--navy); margin: 0 0 1pt; letter-spacing: .2px; }
  h1 + h3 { font-size: 9.8pt; font-weight: 500; font-style: italic; color: var(--muted); margin: 0 0 2pt; }
  h1 + h3 + p { font-size: 8pt; color: var(--muted); margin: 0 0 3pt; }
  h2 {
    font-size: 11pt; color: var(--navy); margin: 4pt 0 3pt;
    padding-bottom: 2pt; border-bottom: 2px solid var(--accent);
    break-before: page;
  }
  h2#sec-1 { break-before: auto; }
  h2#appendix { break-before: auto; break-after: avoid; margin-top: 4pt; font-size: 8.8pt; padding-bottom: 1pt; }
  h2#appendix ~ p { font-size: 7.4pt; color: var(--muted); }
  h3 { font-size: 9pt; color: var(--accent); margin: 3.5pt 0 1.5pt; }
  p { margin: 2pt 0; }
  ul, ol { margin: 1.5pt 0 2.5pt; padding-left: 13pt; }
  li { margin: 0.5pt 0; }
  strong { color: #0f2237; }
  hr { border: none; margin: 0; }
  blockquote {
    margin: 2.5pt 0; padding: 3.5pt 7pt; background: var(--panel);
    border-left: 3px solid var(--accent); border-radius: 2px;
    break-inside: avoid;
  }
  blockquote p { margin: 1pt 0; }
  table {
    width: 100%; border-collapse: collapse; margin: 2.5pt 0;
    font-size: 7.6pt; break-inside: avoid;
  }
  th { background: #e8eef5; color: var(--navy); text-align: left; }
  th, td { border: 0.6px solid var(--line); padding: 1.6pt 4.5pt; vertical-align: top; }
  tr:nth-child(even) td { background: #f8fafc; }
  em { color: var(--muted); }
  .mermaid-wrap { text-align: center; margin: 1.5pt 0; break-inside: avoid; }
  .mermaid-wrap svg { max-width: 100%; height: auto; }
  pre.mermaid { margin: 0; }
  /* Per-diagram size caps (mm heights) */
  .mw-0 svg  { max-height: 13mm; }   /* D-01 problem->solution chain */
  .mw-1 svg  { max-height: 55mm; }   /* D-02 architecture */
  .mw-2 svg  { max-height: 26mm; }   /* D-03 data flow */
  .mw-3 svg  { max-height: 47mm; max-width: 86%; }  /* D-04 AI pipeline */
  .mw-4 svg  { max-height: 21mm; }   /* D-05 financial state */
  .mw-5 svg  { max-height: 52mm; max-width: 88%; }  /* D-06 canonical sequence */
  .mw-6 svg  { max-height: 70mm; }   /* D-07 governance core */
  .mw-7 svg  { max-height: 26mm; }   /* D-08 request lifecycle */
  .mw-8 svg  { max-height: 22mm; }   /* D-09 role lifecycle */
  .mw-9 svg  { max-height: 12mm; }   /* D-10 security flow */
  .mw-10 svg { max-height: 28mm; max-width: 84%; }  /* D-11 implementation */
  .mw-11 svg { max-height: 34mm; max-width: 78%; }  /* D-12 hero demo seq */
</style>
</head>
<body>
${body}
<script src="https://cdn.jsdelivr.net/npm/mermaid@10.9.1/dist/mermaid.min.js"></script>
<script>
  // Assign stable ids to h2 for page-break control
  const h2s = document.querySelectorAll('h2');
  h2s.forEach((h) => {
    const t = h.textContent.trim();
    if (/^1\\./.test(t)) h.id = 'sec-1';
    if (/^Technical Appendix/.test(t)) h.id = 'appendix';
  });
  mermaid.initialize({
    startOnLoad: false,
    theme: 'base',
    themeVariables: {
      primaryColor: '#e8eef7', primaryBorderColor: '#1f5c8b', primaryTextColor: '#14273c',
      lineColor: '#5a7089', secondaryColor: '#f2f6fa', tertiaryColor: '#fbfcfe',
      fontFamily: '"Helvetica Neue", Helvetica, Arial, sans-serif', fontSize: '13px',
      clusterBkg: '#f4f7fb', clusterBorder: '#b9c7d6',
      actorBkg: '#e8eef7', actorBorder: '#1f5c8b', actorTextColor: '#14273c',
      signalColor: '#33475c', signalTextColor: '#33475c',
      labelBoxBkgColor: '#f2f6fa', noteBkgColor: '#fdf6e3'
    },
    flowchart: { useMaxWidth: true, nodeSpacing: 16, rankSpacing: 18, padding: 4, curve: 'linear' },
    sequence: { useMaxWidth: true, actorMargin: 14, width: 105, height: 20, boxMargin: 3, messageMargin: 20, mirrorActors: false, bottomMarginAdj: 2 },
    state: { useMaxWidth: true }
  });
  mermaid.run({ querySelector: 'pre.mermaid' }).then(() => { window.__mermaidDone = true; })
    .catch((e) => { window.__mermaidError = String(e); window.__mermaidDone = true; });
</script>
</body>
</html>`;

writeFileSync(`${ROOT}/.report-build/report.html`, html);

// --- Print to PDF via installed Chrome ---
const browser = await puppeteer.launch({
  executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  headless: 'new',
});
const page = await browser.newPage();
await page.goto(`file://${ROOT}/.report-build/report.html`, { waitUntil: 'networkidle0' });
await page.waitForFunction('window.__mermaidDone === true', { timeout: 30000 });
const mErr = await page.evaluate(() => window.__mermaidError || null);
if (mErr) console.error('MERMAID ERROR:', mErr);

const pdf = await page.pdf({
  path: `${ROOT}/HackOut26_BharatBanking_Report.pdf`,
  format: 'A4',
  printBackground: true,
  displayHeaderFooter: true,
  headerTemplate: `<div style="font-size:6.5pt;color:#8a97a5;width:100%;padding:0 12mm;display:flex;justify-content:space-between;font-family:Helvetica,Arial,sans-serif;">
      <span>HackOut'26 — AI-Powered Hyper-Personalized Banking for Bharat</span><span>Saarthi · Financial Intelligence Layer</span></div>`,
  footerTemplate: `<div style="font-size:6.5pt;color:#8a97a5;width:100%;padding:0 12mm;display:flex;justify-content:space-between;font-family:Helvetica,Arial,sans-serif;">
      <span>Team Saarthi-AI · Hackathon design proposal (prototype)</span><span>Page <span class="pageNumber"></span> of <span class="totalPages"></span></span></div>`,
  margin: { top: '12mm', bottom: '12mm', left: '10mm', right: '10mm' },
});
await browser.close();

const doc = await PDFDocument.load(pdf);
console.log('PDF pages:', doc.getPageCount());
