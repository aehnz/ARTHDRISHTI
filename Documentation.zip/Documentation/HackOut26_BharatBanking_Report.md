# AI-Powered Hyper-Personalized Banking for Bharat

### From one-size-fits-all banking to context-aware financial intelligence

**Platform: Saarthi — a governed Financial Intelligence Layer for banking** · HackOut'26 · Theme: Digital Transformation in Lending

---

## 1. Problem → Insight → Solution

### 1.1 Problem Understanding

India's digital banking rails (UPI, net banking, mobile apps, video KYC) are world-class, yet the *experience* on top of them is generic. Per the HackOut'26 problem statement:

- Customers — especially in **Tier 2/3/4 towns and rural India** — find banking apps **confusing, generic, and disconnected** from their actual financial needs.
- Banks face **rising acquisition costs, high drop-offs** in loan/product journeys, and poor cross-sell relevance — despite holding **rich transactional and behavioral data**.
- Product offers arrive as **generic pop-ups**, not at the right moment for the right customer.
- First-time digital users lack **vernacular, conversational** journeys for onboarding, KYC, and loans.
- **Financial stress and fraud signals** (missed EMIs, sudden behavior change, unusual transactions) are detected late and handled punitively rather than empathetically.

The challenge asks for three capabilities, which we treat as core requirements:

| ID | Requirement (from problem statement) |
|---|---|
| **REQ-01** | Analyze transactions, spending patterns, and life-stage signals to **proactively recommend the most relevant product at the right moment** |
| **REQ-02** | **Simplify and personalize journeys** (onboarding, loan, KYC) via **vernacular conversational AI**, reducing drop-offs for first-time users |
| **REQ-03** | **Detect early financial-stress/fraud signals** and trigger **proactive, empathetic interventions**, not purely punitive actions |

### 1.2 Core Insight

> **Personalization should be state-aware, not profile-only.**
> A customer's demographic profile is static; their financial life is not. The same customer is a good loan candidate in March and a financially stressed one in August. Recommendations must therefore depend on **transaction behavior, income patterns, savings behavior, EMI patterns, spending shifts, life-stage signals, and risk/anomaly signals** — a continuously updated *financial state*, not a segment label.

### 1.3 Product Vision

**Saarthi** is an **AI-powered financial intelligence layer** that continuously understands a customer's evolving financial state and delivers **personalized, explainable, vernacular-first, and responsible** financial guidance. The conversational AI is an *interface over controlled banking intelligence* — the LLM never independently makes high-impact financial decisions; deterministic models, policy, and a Governance Core do.

### 1.4 Primary Capabilities

| # | Capability | # | Capability |
|---|---|---|---|
| 1 | Financial Intelligence (state modeling) | 4 | Vernacular Conversational Banking |
| 2 | Hyper-Personalized Recommendations | 5 | Responsible AI / Governance Core |
| 3 | Financial Stress & Anomaly Detection | 6 | Explainable Decisions |

### 1.5 D-01 — Problem-to-Solution Flow

*How raw data becomes a governed, explainable action:*

```mermaid
flowchart LR
    A[Customer Data] --> B[Financial Behavior] --> C[Financial State] --> D[Predicted Need] --> E[Contextual Decision] --> F[Governance] --> G[Explainable Personalized Action]
```

*Every recommendation traverses this full chain — no path from data directly to offer.*

### 1.6 User / Stakeholder Snapshot

| Actor | Need |
|---|---|
| Customer (incl. Tier 2/3/4, first-time digital) | Relevant, understandable, trustworthy guidance in their language |
| Bank | Better personalization, engagement, lower drop-offs, earlier risk intelligence |
| Support / Relationship Manager | Actionable customer context for empathetic intervention |
| Governance / Audit | Explainable, auditable, policy-compliant decisions |

---

## 2. System Architecture

The architecture separates seven concerns so each can be built, governed, and scaled independently: **customer interaction → orchestration → intelligence → decisioning → governance → action → audit**. Intelligence services *propose*; the Decision Engine *composes*; the Governance Core *disposes*.

### 2.1 D-02 — High-Level System Architecture

```mermaid
flowchart LR
    C[Customer Channels<br/>Web · Mobile · Voice] --> G[API Gateway<br/>AuthN · Rate Limit] --> O[Decision Orchestrator]
    V[Vernacular Conversation Layer<br/>Intent · NLU · LLM response] <--> O
    subgraph INT[Intelligence Services]
      direction TB
      P[Customer Profile Service] ~~~ H[Financial Health Engine] ~~~ F[Risk & Anomaly Engine]
      T[Transaction Intelligence] ~~~ R[Recommendation Engine]
    end
    O --> INT
    INT --> D[Decision Engine<br/>deterministic policy<br/>+ model outputs]
    D --> GC[Governance Core]
    GC --> X[Explainability Service] --> A[Personalized Action<br/>returned to channel]
    GC --> A
    D --> AL[(Audit & Observability)]
    GC --> AL
```

### 2.2 Component Responsibilities

| Component | Responsibility |
|---|---|
| Customer Channels | Web/mobile dashboard, chat, and voice entry points |
| API Gateway | Authentication, authorization, rate limiting, request validation |
| Decision Orchestrator | Coordinates intelligence calls; owns the request lifecycle |
| Customer Profile Service | Consent-scoped profile, life-stage signals, preferences, language |
| Transaction Intelligence | Categorization, enrichment, behavioral pattern extraction |
| Financial Health Engine | Computes financial-state vector and health score (REQ-01/03) |
| Recommendation Engine | Ranks candidate products/actions against current financial state |
| Risk & Anomaly Engine | Stress and fraud early-warning signals with confidence (REQ-03) |
| Vernacular Conversation Layer | Intent detection, multilingual NLU, grounded LLM responses (REQ-02) |
| Decision Engine | Deterministic composition of model outputs into one proposed action |
| Governance Core | Consent, policy, fairness, suitability, predatory-nudge control plane |
| Explainability Service | Human-readable (and vernacular) reason codes for every action |
| Audit & Observability | Immutable decision log, metrics, model monitoring |

### 2.3 Technology Stack *(proposed choices — the problem statement marks technology as advisory)*

| Layer | Proposed Technology | Why |
|---|---|---|
| Frontend | React / Next.js | Fast interactive personalized dashboard |
| Backend | Python + FastAPI | AI/ML-native, async, typed APIs |
| Database | PostgreSQL | Structured transactional + decision data |
| ML | scikit-learn / XGBoost | Interpretable tabular prediction — right tool for financial features |
| NLP / LLM | Multilingual LLM + IndicNLP-class models | Vernacular intent + grounded response generation |
| Vector Search | pgvector | Semantic context retrieval without an extra datastore |
| Cache | Redis | Low-latency financial-state/context reads |
| Messaging | Kafka (RabbitMQ acceptable for MVP) | Event-driven feature and state updates |
| Visualization | Recharts / D3.js | Financial-health and explanation visuals |
| Auth | OAuth2 / JWT | Standard secure access |
| Deploy / Cloud | Docker → AWS/Azure/GCP (India regions) | Reproducible; supports data-localization design intent |
| Monitoring | Prometheus / Grafana | Service + model observability |

### 2.4 Architecture Design Principles

**1. Intelligence before interface** — the chat layer renders decisions, it doesn't make them. **2. Governance before action** — no customer-visible action bypasses the Governance Core. **3. Explainability by design** — every decision carries reason codes at creation, not post-hoc. **4. Customer benefit over upsell** — suitability can veto revenue. **5. Least-privilege, consent-scoped access** — services see only purpose-approved data. **6. Modular, stateless, horizontally scalable services.**

---

## 3. Data & Intelligence Architecture

### 3.1 D-03 — Data Flow Model

*Assumption: the prototype uses a synthetic transaction dataset; production would ingest core-banking / Account Aggregator data under consent.*

```mermaid
flowchart LR
    S[Banking Data Sources<br/>synthetic in prototype] --> V[Validation & Normalization] --> ETL[Feature Engineering] --> F[Feature Layer]
    F --> P[Customer Profile]
    F --> H[Financial Health]
    F --> R[Risk Signals]
    F --> RP[Recommendation Features]
    P --> D[Decision Engine]
    H --> D
    R --> D
    RP --> D
    D --> G[Governance Core] --> O[Customer Output]
```

### 3.2 D-04 — AI/ML Intelligence Pipeline

```mermaid
flowchart TB
    T[Transaction Data] --> FE[Feature Engineering]
    FE --> SG[Behavioral Segmentation<br/>clustering, life-stage signals]
    FE --> AD[Anomaly & Stress Detection<br/>Isolation Forest + rules]
    FE --> RM[Recommendation Modeling<br/>gradient-boosted ranking]
    SG --> CP[Customer Profile]
    AD --> RSig[Risk Signals + confidence]
    RM --> CA[Candidate Actions]
    CP --> FS[Financial State]
    RSig --> FS
    CA --> DE[Decision Engine]
    FS --> DE
```

**Why each model exists:** *Segmentation* discovers behavioral cohorts (salaried, seasonal-income, gig) that condition recommendations. *Anomaly/stress detection* combines unsupervised outlier detection with interpretable rules (missed EMIs, cash-flow collapse) and outputs **confidence scores**, never verdicts. *Recommendation modeling* ranks products by predicted relevance **and** suitability to the current state. The **LLM is used only for language** — intent understanding and vernacular explanation of already-governed decisions — never for eligibility, scoring, or approval math.

### 3.3 Feature Engineering *(representative features; formulas are proposed implementation logic)*

| Group | Representative Features |
|---|---|
| Income | Income stability index, income trend, salary-credit regularity |
| Spending | Category distribution, spending volatility, discretionary-spend ratio |
| Debt | EMI-to-income ratio, active loan count, repayment consistency |
| Savings | Savings rate, savings trend, liquidity coverage (months of expenses) |
| Behavioral | Transaction-frequency shifts, unusual merchant patterns, sudden cash-flow changes |

### 3.4 D-05 — Financial State Model

> Raw transactions are never mapped directly to products. They are transformed into a structured, versioned **financial state** — the single object all downstream decisioning consumes.

```mermaid
flowchart LR
    T[Transactions] --> F[Financial Features] --> S[Financial State]
    S --> CF[Cash Flow]
    S --> DB[Debt Burden]
    S --> SV[Savings]
    S --> RS[Risk Signals]
    CF --> FS[Financial State Vector]
    DB --> FS
    SV --> FS
    RS --> FS
```

### 3.5 D-06 — Canonical Request / Decision Flow

*One canonical lifecycle connects request handling, intelligence, decisioning, governance, explainability, and audit — every journey (dashboard, chat, proactive nudge) is an instance of it:*

```mermaid
sequenceDiagram
    actor Customer
    participant App
    participant Gateway
    participant Decision as Decision Engine
    participant Intelligence
    participant Governance as Governance Core
    participant Audit
    Customer->>App: Request financial guidance
    App->>Gateway: Authenticated request
    Gateway->>Decision: Authorized request
    Decision->>Intelligence: Build customer context
    Intelligence-->>Decision: Financial state + candidate actions
    Decision->>Governance: Validate proposed action
    Governance-->>Decision: Approve / Modify / Block
    Decision->>Audit: Record decision + reasons
    Decision-->>App: Explainable response
    App-->>Customer: Personalized vernacular guidance
```

---

## 4. Responsible AI, Governance & Security

The problem statement explicitly requires safeguards for **data privacy and consent (DPDP Act, RBI data localization norms), algorithmic bias, and avoiding predatory nudging** (e.g., not over-recommending loans to financially stressed customers). Saarthi treats these not as a checklist but as an **architectural control plane**: the Governance Core is a mandatory gate between every AI-proposed decision and the customer.

### 4.1 D-07 — Governance Core

```mermaid
flowchart TB
    R[AI-Proposed Decision] --> C[Consent Check<br/>GOV-01] --> P[Purpose Limitation<br/>GOV-02] --> E[Eligibility & Policy<br/>GOV-03] --> B[Fairness / Bias Check<br/>GOV-04] --> RS[Risk & Suitability<br/>GOV-05] --> PN[Predatory-Nudge Check<br/>GOV-06] --> EX[Explainability Gate<br/>GOV-07]
    EX -->|PASS| A[Approve] --> AU[(Audit Log)]
    EX -->|FAIL| BL[Block / Modify / Escalate to human] --> AU
```

### 4.2 Governance Decision Rule — "No product" is a valid outcome

The system must be able to decide that **no product should be recommended**. Example (GOV-06 in action):

**Financial stress ↑ → loan suitability ↓ → Governance blocks the loan offer → customer receives financial guidance and repayment support instead.** This directly implements the problem statement's demand for customer-benefit-first personalization and empathetic intervention (REQ-03) — the opposite of upsell-driven design.

### 4.3 D-08 — Request Lifecycle

```mermaid
stateDiagram-v2
    direction LR
    [*] --> Received
    Received --> Validated
    Validated --> Authenticated
    Authenticated --> Authorized
    Authorized --> Contextualized
    Contextualized --> Analyzed
    Analyzed --> Governed
    Governed --> Approved
    Governed --> Modified
    Governed --> Blocked
    Approved --> Completed
    Modified --> Completed
    Blocked --> Escalated
    Completed --> Audited
    Escalated --> Audited
    Audited --> [*]
```

### 4.4 D-09 — Role / Access Lifecycle

Access control combines **RBAC** (customer, RM, risk officer, auditor, admin roles) with **ABAC** attributes (consent scope, purpose, data sensitivity): a role grants a *ceiling*, attributes decide each request. Every state change is audited.

```mermaid
stateDiagram-v2
    direction LR
    [*] --> Provisioned
    Provisioned --> Verified
    Verified --> Active
    Active --> RoleChanged
    RoleChanged --> Active
    Active --> Suspended
    Suspended --> Active
    Active --> Deactivated
    Deactivated --> [*]
```

### 4.5 D-10 — Security & Privacy Flow

```mermaid
flowchart LR
    A[Authentication] --> B[Authorization] --> C[Consent] --> D[Purpose Validation] --> E[Data Minimization] --> F[Encrypted Processing] --> G[Decision] --> H[Audit]
```

**Posture:** encryption in transit and at rest; tokenized customer identifiers inside AI services; consent recorded per purpose with revocation honored downstream; India-region data residency as a deployment constraint (RBI localization alignment); human escalation path for blocked or ambiguous decisions. Saarthi is **designed for regulatory readiness and alignment** with DPDP and RBI expectations — we claim design alignment, **not legal compliance certification**.

---

## 5. Implementation, Validation & Impact

### 5.1 D-11 — Implementation Architecture (prototype)

```mermaid
flowchart TB
    UI[React / Next.js UI] --> API[FastAPI Backend]
    API --> AUTH[Auth · OAuth2/JWT]
    API --> SERVICES[Domain Services]
    SERVICES --> DB[(PostgreSQL + pgvector)]
    SERVICES --> CACHE[(Redis)]
    SERVICES --> MQ[Event Bus]
    SERVICES --> ML[ML Services<br/>scoring · anomaly · ranking]
    SERVICES --> LLM[Conversational AI<br/>vernacular NLU + generation]
    ML --> GOV[Governance Core]
    LLM --> GOV
    SERVICES --> GOV
    GOV --> AUD[(Audit / Observability)]
```

### 5.2 Hackathon MVP Scope

| **MUST HAVE (hackathon build)** | **SHOULD HAVE** | **FUTURE / PRODUCTION** |
|---|---|---|
| 1. Synthetic transaction dataset · 2. Transaction categorization · 3. Feature engineering · 4. Financial-health scoring · 5. Recommendation engine · 6. Stress/anomaly detection · 7. Vernacular conversational interface · 8. Governance engine · 9. Explainable dashboard · 10. End-to-end journey | Event-driven state updates · scenario simulation ("what if I take this loan?") · multilingual voice · model monitoring | Real core-banking / Account Aggregator integration · production identity systems · regulatory certification · large-scale model serving |

*Deliberate separation: feasibility is demonstrated end-to-end on synthetic data — the prototype is never claimed to be a production banking system.*

### 5.3 Hero Demo *(illustrative prototype interaction — not real financial advice)*

Customer asks in Hindi: **"Mujhe ₹5 lakh ka personal loan lena chahiye?"** ("Should I take a ₹5 lakh personal loan?") — and the full D-01 chain executes live against their financial state:

> **Saarthi:** "Aapke haaliya cash-flow aur maujooda EMI bojh ko dekhte hue, naya loan financial stress badha sakta hai — isliye abhi loan recommend nahi kar rahe. Iske bajay repayment plan aur monthly cash flow behtar karne ke sujhav de rahe hain." *(English: another loan may increase financial stress — review your repayment plan instead.)* — tap-to-view reasons: EMI-to-income 41%, savings buffer 0.8 months, 2 recent EMI delays.

One interaction demonstrates **personalization, AI reasoning, financial-state awareness, governance, explainability, and vernacular interaction** — declining revenue to protect the customer. *D-12 — Hero Demo Sequence:*

```mermaid
sequenceDiagram
    actor C as Customer
    participant V as Vernacular Layer
    participant D as Decision Engine
    participant I as Intelligence
    participant G as Governance Core
    C->>V: Loan query (Hindi)
    V->>D: Intent: loan-suitability query
    D->>I: Financial state + loan candidate
    I-->>D: Stress ↑, EMI/income 41%, low buffer
    D->>G: Proposed: personal loan offer
    G-->>D: BLOCK (GOV-06) → guidance action
    D-->>V: Decision + reason codes
    V-->>C: Empathetic vernacular explanation
```

### 5.4 Evaluation — *targets for the prototype (no measured results yet; synthetic data)*

| Capability | Example Metric | Capability | Example Metric |
|---|---|---|---|
| Recommendation | Precision@K / relevance | Explainability | Explanation coverage (% decisions with reasons) |
| Stress detection | Precision / Recall / F1 | Governance | Unsafe-action block rate |
| Anomaly detection | False-positive rate | System | p95 latency / error rate |
| Intent detection | Accuracy / F1 per language | Fairness | Group disparity metrics across cohorts |

### 5.5 Impact & Scalability *(mapped to the problem statement)*

**Customer:** relevant guidance at the right moment; simpler vernacular journeys; earlier, empathetic stress support. **Bank:** deeper personalization, lower journey drop-off, better product relevance, earlier risk signals. **Society:** broader financial inclusion for Tier 2/3/4 and first-time users. *(No quantitative impact claims without evidence.)*

**Path to scale:** *stateless APIs → horizontal scaling → event-driven processing → independently scalable AI services → distributed data layer → monitoring + model governance.* Service boundaries (D-02) are the production boundaries: swapping synthetic ingestion for core-banking/Account-Aggregator events evolves the same architecture — not a rewrite — into a bank-scale platform on existing digital infrastructure.

### 5.6 Differentiation

| Generic AI Banking App | Saarthi | Generic AI Banking App | Saarthi |
|---|---|---|---|
| Chatbot-first | **Intelligence-first** | AI as black box | **Governed + explainable AI** |
| Product upsell | **Customer-benefit optimization** | English-first | **Vernacular-first** |
| Static profile | **Dynamic financial state** | Reactive support | **Proactive financial intervention** |
| Generic recommendations | **Context-aware recommendations** | Feature-centric | **Decision-centric** |

> **Final architectural principle — Understand before recommending. Govern before acting. Explain before influencing. Protect before selling.**

---

## Technical Appendix / Repository

Complete engineering artifacts are maintained separately in the project repository: full HLD & LLD · DFD Levels 0/1/2 · ER diagram & database schemas · API and event contracts · sequence diagrams & state machines · role/request/recommendation lifecycles · model architecture, feature definitions & evaluation · governance policies · threat model & privacy model · deployment architecture, CI/CD, observability, failure handling, scalability design · data lineage.
